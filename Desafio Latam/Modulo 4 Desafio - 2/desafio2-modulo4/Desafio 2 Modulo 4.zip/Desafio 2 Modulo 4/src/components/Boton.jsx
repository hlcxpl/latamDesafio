import React from 'react'

function Boton() {
  return (
    <button className="btn btn-primary">Boton</button>
  )
}

export default Boton