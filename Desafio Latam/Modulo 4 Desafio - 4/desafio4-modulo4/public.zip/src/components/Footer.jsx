import React from 'react'

const Footer = () => {
    return (
        <div>
            <div className="bd-footer py-4 py-md-5 text-center bg-dark text-light">
                <h3>| Dias Feriados Footer |<hr/> <p style={{fontSize: '1rem'}}>Todos los derechos reservados</p></h3>
            </div>
        </div>
    )
}

export default Footer