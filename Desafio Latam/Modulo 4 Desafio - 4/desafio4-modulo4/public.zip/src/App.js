import React from "react";
import Miapi from "./components/Miapi";

function App() {

  return (
    <div className="App ">
      <Miapi />
    </div>
  );
}

export default App;
